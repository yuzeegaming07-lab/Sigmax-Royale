import * as THREE from 'three';

const root=document.querySelector('#scene');
const scene=new THREE.Scene();
scene.background=new THREE.Color(0x8fc8e6);
scene.fog=new THREE.Fog(0x8fc8e6,25,95);
const camera=new THREE.PerspectiveCamera(48,innerWidth/innerHeight,.1,180);
const renderer=new THREE.WebGLRenderer({antialias:true,alpha:false});
renderer.setPixelRatio(Math.min(devicePixelRatio,1.7));
renderer.setSize(innerWidth,innerHeight);
renderer.shadowMap.enabled=true;
renderer.shadowMap.type=THREE.PCFSoftShadowMap;
root.appendChild(renderer.domElement);

let cameraSensitivity=0.008, movementSpeed=0.105, cameraDistance=7;
let reloadStyle='tactical', ammo=20, maxAmmo=20, reloading=false;
const qualitySettings={
 low:{pixel:0.8,shadows:false},
 medium:{pixel:1.2,shadows:true},
 high:{pixel:1.6,shadows:true},
 ultra:{pixel:2,shadows:true}
};
function applyQuality(level){
 const q=qualitySettings[level]||qualitySettings.medium;
 renderer.setPixelRatio(Math.min(devicePixelRatio,q.pixel));
 renderer.shadowMap.enabled=q.shadows;
 renderer.setSize(innerWidth,innerHeight);
}
const savedSettings=JSON.parse(localStorage.getItem('spaceRoyaleSettings')||'{}');


scene.add(new THREE.HemisphereLight(0xe6f6ff,0x4c624d,2.1));
const sun=new THREE.DirectionalLight(0xffedcf,2.5);
sun.position.set(-12,22,14);sun.castShadow=true;sun.shadow.mapSize.set(1024,1024);scene.add(sun);

const mat=(color,roughness=.8,metalness=0)=>new THREE.MeshStandardMaterial({color,roughness,metalness});
const floor=new THREE.Mesh(new THREE.CircleGeometry(65,64),mat(0x568d59));floor.rotation.x=-Math.PI/2;floor.position.y=-.15;floor.receiveShadow=true;scene.add(floor);
const sea=new THREE.Mesh(new THREE.CircleGeometry(78,64),mat(0x287eaa,.45));sea.rotation.x=-Math.PI/2;sea.position.y=-.45;scene.add(sea);

function cube(parent,x,y,z,w,h,d,color){
 const m=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),mat(color));m.position.set(x,y,z);m.castShadow=true;m.receiveShadow=true;parent.add(m);return m;
}
function makeBuilding(x,z,color,roof){
 const g=new THREE.Group();scene.add(g);g.position.set(x,0,z);
 cube(g,0,1.2,0,7,2.4,6,color);cube(g,0,2.55,0,7.5,.45,6.5,roof);
 for(let sx of [-2.1,2.1]){cube(g,sx,1.25,-3.04,1.1,1.3,.08,0x4d7790);cube(g,sx,1.25,3.04,1.1,1.3,.08,0x4d7790)}
 return g;
}
makeBuilding(-11,-9,0xe0bb82,0x8b5947);
makeBuilding(11,-10,0xb5cbd1,0x526e85);
makeBuilding(0,12,0xd8d0a0,0x557e9b);
for(let i=0;i<30;i++){
 const a=i*2.399,r=19+(i%5)*2.5,x=Math.cos(a)*r,z=Math.sin(a)*r;
 const t=new THREE.Mesh(new THREE.CylinderGeometry(.18,.28,1.7,7),mat(0x77553b));t.position.set(x,.85,z);scene.add(t);
 const c=new THREE.Mesh(new THREE.SphereGeometry(1.25,8,7),mat(i%2?0x2e8050:0x3a9259));c.position.set(x,2.3,z);c.scale.y=1.2;c.castShadow=true;scene.add(c);
}

// Original pilot character, built from simple geometric parts.
function createPilot(){
 const g=new THREE.Group();
 const suit=mat(0x314b8c),dark=mat(0x202d46),skin=mat(0xd9a77d),glow=mat(0x68e8ff,.35,.3),gold=mat(0xe4a83e);
 const torso=new THREE.Mesh(new THREE.CapsuleGeometry(.48,.75,5,10),suit);torso.position.y=1.45;torso.castShadow=true;g.add(torso);
 const head=new THREE.Mesh(new THREE.SphereGeometry(.34,16,12),skin);head.position.y=2.22;g.add(head);
 const visor=new THREE.Mesh(new THREE.BoxGeometry(.47,.13,.12),glow);visor.position.set(0,2.25,-.29);g.add(visor);
 for(const s of [-1,1]){
  const arm=new THREE.Mesh(new THREE.CapsuleGeometry(.16,.58,4,8),suit);arm.position.set(s*.59,1.48,-.02);arm.rotation.z=s*-.12;g.add(arm);
  const leg=new THREE.Mesh(new THREE.CapsuleGeometry(.19,.65,4,8),dark);leg.position.set(s*.24,.52,0);g.add(leg);
  const boot=new THREE.Mesh(new THREE.BoxGeometry(.38,.2,.55),gold);boot.position.set(s*.24,.15,-.08);g.add(boot);
 }
 const pack=new THREE.Mesh(new THREE.BoxGeometry(.68,.75,.28),dark);pack.position.set(0,1.48,.48);g.add(pack);
 // Fictional, non-realistic sci-fi prop attached across the front.
 const weapon=new THREE.Group();
 const barrel=new THREE.Mesh(new THREE.BoxGeometry(.18,.18,1.15),dark);barrel.position.z=-.38;weapon.add(barrel);
 const receiver=new THREE.Mesh(new THREE.BoxGeometry(.34,.3,.48),gold);receiver.position.z=.1;weapon.add(receiver);
 const energy=new THREE.Mesh(new THREE.CylinderGeometry(.07,.07,.45,8),glow);energy.rotation.x=Math.PI/2;energy.position.set(0,.12,-.28);weapon.add(energy);
 weapon.position.set(.34,1.52,-.38);weapon.rotation.x=-.08;g.add(weapon);
 return g;
}
const pilot=createPilot();scene.add(pilot);
const lobbyCam={x:0,y:3.5,z:8};
let mode='lobby',moveX=0,moveY=0,camYaw=0,score=0,shots=[];
const target=new THREE.Group();scene.add(target);
const targetBody=new THREE.Mesh(new THREE.CylinderGeometry(.55,.7,1.6,8),mat(0xd76c45));targetBody.position.y=.8;target.add(targetBody);
const targetTop=new THREE.Mesh(new THREE.SphereGeometry(.5,12,8),mat(0xf2c28b));targetTop.position.y=1.9;target.add(targetTop);target.position.set(0,0,-13);
function setCamera(){
 if(mode==='lobby'){
  camera.position.set(lobbyCam.x,lobbyCam.y,lobbyCam.z);camera.lookAt(0,1.35,0);
 }else{
  const p=pilot.position;
  const offset=new THREE.Vector3(Math.sin(camYaw)*cameraDistance,3.6,Math.cos(camYaw)*cameraDistance);
  camera.position.copy(p).add(offset);camera.lookAt(p.x,p.y+1.35,p.z);
 }
}
setCamera();

const panelText={
 character:'<b>ASTRA • PILOT 01</b><br>Karakter awal<br><br>Setelan: Explorer Suit<br>Peran: Scout<br><br><span style="color:#b9d9ff">Karakter original Sigmax-Royale</span>',
 loadout:'<b>LOADOUT</b><br>Pulse Carbine<br>Senjata energi fiksi<br><br>Sidearm: Spark Pistol<br><span style="color:#b9d9ff">Item sementara untuk prototype</span>',
 inventory:'<b>INVENTORI</b><br>Field Pack × 1<br>Med Kit × 2<br>Shield Cell × 2<br>Energy Core × 1',
 store:'<b>MARKET</b><br>Coming soon<br><br>Kosmetik original akan ditambahkan pada update berikutnya.'
};
document.querySelectorAll('.tab').forEach(b=>b.addEventListener('click',()=>{
 document.querySelectorAll('.tab').forEach(x=>x.classList.remove('active'));b.classList.add('active');
 document.querySelector('#panel').innerHTML=panelText[b.dataset.panel];
}));
document.querySelector('#play').addEventListener('click',()=>{
 mode='match';document.querySelector('#lobbyUI').style.display='none';document.querySelector('#matchUI').style.display='block';
 pilot.position.set(0,0,0);camYaw=0;setCamera();
});
document.querySelector('#leave').addEventListener('click',()=>{
 mode='lobby';document.querySelector('#matchUI').style.display='none';document.querySelector('#lobbyUI').style.display='block';setCamera();
});
function updateAmmo(){const el=document.querySelector('#ammo');if(el)el.textContent=reloading?'RELOADING…':`ENERGI ${ammo} / ${maxAmmo}`;}
function reload(){
 if(mode!=='match'||reloading||ammo===maxAmmo)return;
 reloading=true;updateAmmo();
 const duration=reloadStyle==='quick'?650:(reloadStyle==='realistic'?1900:1200);
 const started=performance.now();
 const originalY=pilot.rotation.y;
 const tick=()=>{
  if(!reloading)return;
  const p=Math.min(1,(performance.now()-started)/duration);
  pilot.rotation.z=Math.sin(p*Math.PI)*.12;
  if(p<1)requestAnimationFrame(tick);
  else{pilot.rotation.z=0;pilot.rotation.y=originalY;ammo=maxAmmo;reloading=false;updateAmmo();}
 };
 requestAnimationFrame(tick);
}
document.querySelector('#reload').addEventListener('click',reload);
function fire(){
 if(mode!=='match'||reloading)return;
 if(ammo<=0){reload();return;}
 ammo--;updateAmmo();
 const orb=new THREE.Mesh(new THREE.SphereGeometry(.13,10,8),mat(0x7cecff,.2,.4));
 orb.position.copy(pilot.position).add(new THREE.Vector3(0,1.6,-.8).applyAxisAngle(new THREE.Vector3(0,1,0),camYaw));
 const dir=new THREE.Vector3(-Math.sin(camYaw),0,-Math.cos(camYaw));
 shots.push({mesh:orb,dir,life:0});scene.add(orb);
}
document.querySelector('#fire').addEventListener('click',fire);

// Virtual joystick
const stick=document.querySelector('#stick'),knob=document.querySelector('#knob');
let activePointer=null;
function updateStick(e){
 const r=stick.getBoundingClientRect(),cx=r.left+r.width/2,cy=r.top+r.height/2;
 let dx=e.clientX-cx,dy=e.clientY-cy;const len=Math.hypot(dx,dy),max=42;
 if(len>max){dx=dx/len*max;dy=dy/len*max;}
 moveX=dx/max;moveY=dy/max;knob.style.transform=`translate(${dx}px,${dy}px)`;
}
stick.addEventListener('pointerdown',e=>{activePointer=e.pointerId;stick.setPointerCapture(activePointer);updateStick(e)});
stick.addEventListener('pointermove',e=>{if(e.pointerId===activePointer)updateStick(e)});
function releaseStick(e){if(e.pointerId===activePointer){activePointer=null;moveX=moveY=0;knob.style.transform='translate(0,0)'}}
stick.addEventListener('pointerup',releaseStick);stick.addEventListener('pointercancel',releaseStick);

// Drag the right side of the screen to turn the camera.
let dragId=null,lastX=0;
renderer.domElement.addEventListener('pointerdown',e=>{if(mode==='match'&&e.clientX>innerWidth*.38){dragId=e.pointerId;lastX=e.clientX;renderer.domElement.setPointerCapture(dragId)}});
renderer.domElement.addEventListener('pointermove',e=>{if(e.pointerId===dragId){camYaw-=(e.clientX-lastX)*cameraSensitivity;lastX=e.clientX}});
renderer.domElement.addEventListener('pointerup',e=>{if(e.pointerId===dragId)dragId=null});
renderer.domElement.addEventListener('pointercancel',()=>dragId=null);


// Settings panel: graphics, camera sensitivity, movement speed and reload feel.
const settingsModal=document.querySelector('#settingsModal');
const qualityEl=document.querySelector('#quality');
const sensEl=document.querySelector('#sensitivity');
const moveEl=document.querySelector('#moveSpeed');
const reloadEl=document.querySelector('#reloadStyle');
const viewEl=document.querySelector('#cameraView');
function loadSettings(){
 qualityEl.value=savedSettings.quality||'medium';
 sensEl.value=savedSettings.sensitivity||100;
 moveEl.value=savedSettings.moveSpeed||100;
 reloadEl.value=savedSettings.reloadStyle||'tactical';
 viewEl.value=savedSettings.cameraView||'third';
 cameraSensitivity=.008*(Number(sensEl.value)/100);
 movementSpeed=.105*(Number(moveEl.value)/100);
 reloadStyle=reloadEl.value;
 cameraDistance=viewEl.value==='wide'?9:7;
 applyQuality(qualityEl.value);
 document.querySelector('#sensValue').textContent=sensEl.value+'%';
 document.querySelector('#moveValue').textContent=moveEl.value+'%';
}
loadSettings();
document.querySelector('#openSettings').addEventListener('click',()=>{settingsModal.style.display='flex';});
document.querySelector('#closeSettings').addEventListener('click',()=>{settingsModal.style.display='none';});
sensEl.addEventListener('input',()=>document.querySelector('#sensValue').textContent=sensEl.value+'%');
moveEl.addEventListener('input',()=>document.querySelector('#moveValue').textContent=moveEl.value+'%');
document.querySelector('#saveSettings').addEventListener('click',()=>{
 const s={quality:qualityEl.value,sensitivity:Number(sensEl.value),moveSpeed:Number(moveEl.value),reloadStyle:reloadEl.value,cameraView:viewEl.value};
 localStorage.setItem('spaceRoyaleSettings',JSON.stringify(s));
 cameraSensitivity=.008*(s.sensitivity/100);
 movementSpeed=.105*(s.moveSpeed/100);
 reloadStyle=s.reloadStyle;
 cameraDistance=s.cameraView==='wide'?9:7;
 applyQuality(s.quality);
 settingsModal.style.display='none';
 document.querySelector('#notice').textContent='PENGATURAN TERSIMPAN';
});

function animate(){
 requestAnimationFrame(animate);
 const t=performance.now()*.001;
 if(mode==='lobby'){
  pilot.position.set(0,0,0);pilot.rotation.y=Math.sin(t*.35)*.12;
  camera.position.x=Math.sin(t*.12)*.35;camera.lookAt(0,1.35,0);
 }else{
  const forward=new THREE.Vector3(-Math.sin(camYaw),0,-Math.cos(camYaw));
  const right=new THREE.Vector3(Math.cos(camYaw),0,-Math.sin(camYaw));
  const v=forward.multiplyScalar(-moveY).add(right.multiplyScalar(moveX));
  if(v.lengthSq()>.001){v.normalize();pilot.position.addScaledVector(v,movementSpeed);pilot.rotation.y=Math.atan2(-v.x,-v.z)}
  pilot.position.x=THREE.MathUtils.clamp(pilot.position.x,-38,38);
  pilot.position.z=THREE.MathUtils.clamp(pilot.position.z,-38,38);
  camera.position.lerp(new THREE.Vector3(pilot.position.x+Math.sin(camYaw)*cameraDistance,3.6,pilot.position.z+Math.cos(camYaw)*cameraDistance),.12);
  camera.lookAt(pilot.position.x,pilot.position.y+1.3,pilot.position.z);
 }
 target.position.y=Math.sin(t*2)*.08;
 shots=shots.filter(s=>{
  s.mesh.position.addScaledVector(s.dir,.42);s.life++;
  if(s.mesh.position.distanceTo(target.position.clone().add(new THREE.Vector3(0,1,0)))<1.2){
   scene.remove(s.mesh);score++;document.querySelector('#score');document.querySelector('#matchLabel').textContent='MODE LATIHAN • TARGET: '+score;return false;
  }
  if(s.life>80){scene.remove(s.mesh);return false}return true;
 });
 renderer.render(scene,camera);
}
animate();
addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight)});
