# Sigmax-Royale v0.1

Original stylized 3D battle-royale lobby and practice prototype.

## Included
- 3D lobby with an original playable character model
- Original fictional rifle prop and equipment display
- Character, loadout, inventory and store-style lobby panels
- Play button opens a local practice arena
- Touch joystick and camera drag controls in the practice arena
- Settings: graphics quality, camera sensitivity, movement speed, camera distance, reload style
- Practice ammo and reload control
- Capacitor Android wrapper
- GitHub Actions workflow to build a debug APK

## Build an APK using GitHub from your Android phone
1. Create a GitHub repository named `sigmax-royale`.
2. Upload the contents of this folder to the repository root (including the hidden `.github` folder).
3. Open the repository's **Actions** tab and enable Actions if prompted.
4. Select **Build Sigmax-Royale Android APK**, then tap **Run workflow**.
5. Open the completed run and download the `sigmax-royale-debug-apk` artifact.
6. Extract the downloaded ZIP and install `app-debug.apk`.

The workflow also runs on every push to the `main` branch. The APK is a debug/testing build.

## Important scope
This is a first playable prototype, not a finished online game. The lobby, character, fictional weapon prop and UI are original prototype assets. Online matchmaking, real player networking, progression, final 3D art, animation sets, audio and production optimization are future development tasks. It does not copy Sigma's proprietary characters, maps, weapon designs, icons or interface.
